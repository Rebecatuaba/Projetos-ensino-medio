import 'package:flutter/material.dart';

class Tela5 extends StatefulWidget {
  const Tela5({super.key});

  @override
  State<Tela5> createState() => _Tela5State();
}

class _Tela5State extends State<Tela5> {
  @override
  Widget build(BuildContext context) {
    return  SingleChildScrollView(
      child: Column(
        children: [
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),
          Text('oi'),Text('oi'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
          Text('ksdghfjhkdsfkj'),
    
        ],
      ),
    );
  }
}