// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';

import 'tela4.dart';
import 'tela5.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  int indice=3;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 6,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Facebook'),
            bottom: TabBar(
              indicatorColor: Colors.deepPurpleAccent,
              indicatorSize: TabBarIndicatorSize.label,
              tabs: [
                Tab(
                  icon: Icon(Icons.adb_sharp),
                  text: 'Tela 1',
                ),
                Tab(
                  icon: Icon(Icons.adb_sharp),
                  text: 'Tela 1',
                ),
                Tab(
                  icon: Icon(Icons.adb_sharp),
                  text: 'Tela 1',
                ),
                Tab(
                  icon: Icon(Icons.adb_sharp),
                  text: 'Tela 1',
                ),
                Tab(
                  icon: Icon(Icons.adb_sharp),
                  text: 'Tela 1',
                ),
                Tab(
                  icon: Icon(Icons.adb_sharp),
                  text: 'Tela 1',
                ),
              ]
              ),
          ),
          body: TabBarView(
            children: [
              Container(color: Colors.blue,),
              Tela5(),
              Container(color: Colors.red,),
              Container(color: Colors.grey,),
              Container(color: Colors.pink,),
              Container(color: Colors.purple,),
            ],
            )
        ),
      ),
    );
  }
}
