# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\Administrador\\flutter_windows_3.10.2-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "D:\\3º ANO\\Norbas\\mobile\\anime btn\\animation" PROJECT_DIR)

set(FLUTTER_VERSION "0.1.0" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 0 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\Administrador\\flutter_windows_3.10.2-stable\\flutter"
  "PROJECT_DIR=D:\\3º ANO\\Norbas\\mobile\\anime btn\\animation"
  "FLUTTER_ROOT=C:\\Users\\Administrador\\flutter_windows_3.10.2-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=D:\\3º ANO\\Norbas\\mobile\\anime btn\\animation\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=D:\\3º ANO\\Norbas\\mobile\\anime btn\\animation"
  "FLUTTER_TARGET=D:\\3º ANO\\Norbas\\mobile\\anime btn\\animation\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9XRUJfQVVUT19ERVRFQ1Q9dHJ1ZQ==,RkxVVFRFUl9XRUJfQ0FOVkFTS0lUX1VSTD1odHRwczovL3d3dy5nc3RhdGljLmNvbS9mbHV0dGVyLWNhbnZhc2tpdC85MGZhM2FlMjhmZTZkZGFlZTFhZjJjMTIwZjAxZTUwMjAxYzE0MDFiLw=="
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=D:\\3º ANO\\Norbas\\mobile\\anime btn\\animation\\.dart_tool\\package_config.json"
)
